package in.ineuron.main;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = new int[] { 10, 20, 30, 40, 50, 60, 70, 80, 90 };

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter the number for searching..........");
		int search = scanner.nextInt();
		int first = 0;
		int last = array.length - 1;
		boolean flag = false;

		while (first <= last) {
		
			int mid = (first + last) / 2;

			if (search == array[mid]) {
				System.out.println("Searched element is found at index : " + mid);
				flag = true;
				break;
			} else if (search > array[mid]) {
				first = mid + 1;
			} else {
				last = mid;
			}
		}
		if (flag == false) {
			System.out.println("Searched element not found");
		}
		scanner.close();
	}

}
