package in.ineuron.controller;

import java.util.List;
import java.util.Scanner;

import in.ineuron.model.Person;
import in.ineuron.service.IPersonService;
import in.ineuron.service.PersonServiceImpl;
import in.ineuron.util.HibernateUtil;

public class MainTest {

	static {
		HibernateUtil.startUp();
	}
	
	public static void main(String[] args) {
		
		//To save the person record
		savePerson();

		//To get All records
		getAllRecord();

	}

	private static void getAllRecord() {
		IPersonService service = new PersonServiceImpl();

		List<Person> allRecord = service.getAllRecord();

		allRecord.forEach((person) -> System.out.println(person));
	}

	private static void savePerson() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Name      : ");
		String name = scanner.next();
		System.out.print("Enter the Age       : ");
		int age = scanner.nextInt();
		System.out.print("Enter the Address   : ");
		String address = scanner.next();

		Person person = new Person();
		person.setName(name);
		person.setAge(age);
		person.setAdddress(address);

		IPersonService service = new PersonServiceImpl();
		String result = service.save(person);
		if (result.equals("success")) {
			System.out.println("Record Inserted Successfully");
		} else {
			System.out.println("Record Insertion Failed");
		}
	}

}
