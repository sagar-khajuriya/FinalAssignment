package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IPersonDao;
import in.ineuron.dao.PersonDaoImpl;
import in.ineuron.model.Person;

public class PersonServiceImpl implements IPersonService {

	@Override
	public List<Person> getAllRecord() {
		// TODO Auto-generated method stub
		IPersonDao dao = new PersonDaoImpl();
		return dao.getAllRecord();
	}

	@Override
	public String save(Person p) {
		// TODO Auto-generated method stub
		IPersonDao dao = new PersonDaoImpl();
		return dao.save(p);
	}

}
