package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Person;

public interface IPersonService {

	public List<Person> getAllRecord();

	public String save(Person p);
}
