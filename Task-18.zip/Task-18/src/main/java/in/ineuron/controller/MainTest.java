package in.ineuron.controller;

import java.util.List;

import in.ineuron.model.Person;
import in.ineuron.service.IPersonService;
import in.ineuron.service.PersonServiceImpl;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IPersonService service = new PersonServiceImpl();
		List<Person> allRecord = service.getAllRecord();

		allRecord.forEach((person) -> System.out.println(person));

	}

}
