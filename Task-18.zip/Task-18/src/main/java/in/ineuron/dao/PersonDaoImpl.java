package in.ineuron.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import in.ineuron.model.Person;
import in.ineuron.util.HibernateUtil;

public class PersonDaoImpl implements IPersonDao {

	Session session = null;

	@Override
	public List<Person> getAllRecord() {
		// TODO Auto-generated method stub

		session = HibernateUtil.getSession();

		@SuppressWarnings("unchecked")
		Query<Person> query = session.createQuery("from in.ineuron.model.Person");
		List<Person> list = query.list();

		return list;
	}

}
