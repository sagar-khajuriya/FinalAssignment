package in.ineuron.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		List<Integer> list = new ArrayList<>();
		System.out.println("TO STOP ADDING THE VALUE IN LIST PRESS  0 ");
		while (true) {
			System.out.print("Enter the Element : ");
			int element = sc.nextInt();
			if (element == 0) {
				break;
			}
			list.add(element);
		}

		Collections.sort(list);
		System.out.print("Sorted List is ");
		list.forEach(e -> System.out.print(e + " "));

		System.out.println("\nSecond Largest element is " + list.get(1));
		System.out.println("Second Smallest element is " + list.get(list.size() - 2));

		sc.close();
	}

}
