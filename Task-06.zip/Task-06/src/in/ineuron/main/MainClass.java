package in.ineuron.main;

import java.util.List;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = List.of(20,50,45,80,10,25,30);
		
		Stream<Integer> stream = list.stream().sorted();
		stream.forEach(System.out::println);
		System.out.println("****************************");
		list.stream().sorted().filter(n->n%2==0).forEach(data -> System.out.print(data+" "));
	}

}
