package in.ineuron.main;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {

		final ProducerConsumer pc = new ProducerConsumer();
		//Producer Thread
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					pc.producer();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		//Consumer Thread
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					pc.consumer();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});

		// start the threads
		t1.start();
		t2.start();
		
	}

}
