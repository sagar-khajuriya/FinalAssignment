package in.ineuron.main;

import java.util.LinkedList;
import java.util.Random;

public class ProducerConsumer {

	LinkedList<Integer> list = new LinkedList<>();
	int capacity = 1;

	// Producer
	public void producer() throws InterruptedException {
		Random r = new Random();
		while (true) {
			int value = r.nextInt(50);
			synchronized (this) {
				while (list.size() == capacity)
					wait();
				System.out.println("Producer produced : " + value);
				list.add(value);
				notify();
				Thread.sleep(1000);
			}
		}

	}

	// Consumer
	public void consumer() throws InterruptedException {
		int sum=0;
		while (true) {
			synchronized (this) {
				while (list.size() == 0)
					wait();
				int val = list.removeFirst();
				sum=sum+val;
				System.out.println("Consumer consumed : " + val);
				System.out.println("Sum of consumed value : "+sum);
				notify();
				Thread.sleep(1000);
			}

		}
	}

}
