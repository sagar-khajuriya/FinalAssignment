package in.ineuron.dao;

import java.util.List;

import in.ineuron.model.Person;

public interface IPersonDao {

	public List<Person> getAllRecord();

	public String update(Person p);
	
	public Person search(Integer id);
	
}
