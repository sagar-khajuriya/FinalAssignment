package in.ineuron.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import in.ineuron.model.Person;
import in.ineuron.util.HibernateUtil;

public class PersonDaoImpl implements IPersonDao {

	private Session session = null;
	private Transaction transaction = null;;

	@Override
	public List<Person> getAllRecord() {
		// TODO Auto-generated method stub

		session = HibernateUtil.getSession();

		@SuppressWarnings("unchecked")
		Query<Person> query = session.createQuery("from in.ineuron.model.Person");
		List<Person> list = query.list();

		return list;
	}

	@Override
	public String update(Person p) {
		// TODO Auto-generated method stub
		boolean flag = false;
		String result = "fail";
		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {
				session.update(p);
				flag = true;
				result = "success";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
			} else {
				transaction.rollback();
			}
		}
		return result;
	}

	@Override
	public Person search(Integer id) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Person person = null;

		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {
				person = session.get(Person.class, id);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
			} else {
				transaction.rollback();
			}
		}
		return person;

	}

}
