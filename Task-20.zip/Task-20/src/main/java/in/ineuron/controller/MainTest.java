package in.ineuron.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import in.ineuron.model.Person;
import in.ineuron.service.IPersonService;
import in.ineuron.service.PersonServiceImpl;
import in.ineuron.util.HibernateUtil;

public class MainTest {

	static {
		HibernateUtil.startUp();
	}

	public static void main(String[] args) throws IOException {

		// To save the person record
		updatePerson();

		// To get All records
		getAllRecord();

	}

	private static void getAllRecord() {
		IPersonService service = new PersonServiceImpl();

		List<Person> allRecord = service.getAllRecord();

		allRecord.forEach((person) -> System.out.println(person));
	}

	private static void updatePerson() throws IOException {

		IPersonService service = new PersonServiceImpl();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Enter the Id  : ");
		String id = br.readLine();

		Person person = service.search(Integer.parseInt(id));
		if (person != null) {
			Person newPerson = new Person();

			newPerson.setId(person.getId());
			
			System.out.print("Your old name : " + person.getName() + " Enter the Name      : ");
			String name = br.readLine();
			if (name.equals("")) {
				newPerson.setName(person.getName());
			} else {
				newPerson.setName(name);
			}

			System.out.print("Your old age : " + person.getAge() + " Enter the Age       : ");
			String age = br.readLine();
			if (age.equals("")) {
				newPerson.setAge(person.getAge());
			} else {
				newPerson.setAge(Integer.parseInt(age));
			}

			System.out.print("Your old address : " + person.getAdddress() + " Enter the Address   : ");
			String address = br.readLine();
			if (address.equals("")) {
				newPerson.setAdddress(person.getAdddress());
			} else {
				newPerson.setAdddress(address);
			}

			String result = service.update(newPerson);
			if (result.equals("success")) {
				System.out.println("Record updated successfully");
			} else {
				System.out.println("Record Not Updated Successfully");
			}
		} else {
			System.out.println("Record Not Found");
		}

	}
}
