package in.ineuron.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.Person;

public class PersonDao {

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Connection connection = null;
	private PreparedStatement pstmt = null;
	private ResultSet resultSet = null;
	private List<Person> list = null;

	public List<Person> getAllRecord() {

		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ineuron", "root", "password");

			if (connection != null) {
				pstmt = connection.prepareStatement("select * from person");
			}
			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}
			if (resultSet != null) {
				list = new ArrayList<>();
				Person p = null;
				while (resultSet.next()) {
					p = new Person();
					p.setId(resultSet.getInt(1));
					p.setName(resultSet.getString(2));
					p.setAge(resultSet.getInt(3));
					p.setAddress(resultSet.getString(4));
					list.add(p);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
