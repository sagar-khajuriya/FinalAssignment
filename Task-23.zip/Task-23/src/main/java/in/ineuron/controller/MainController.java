package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.ineuron.model.Person2;
import in.ineuron.service.IPersonService;

@Controller
public class MainController {

	@Autowired
	private IPersonService service;

	@GetMapping("/load")
	public String loadPage() {
		return "saveperson";
	}

	@PostMapping("/save")
	public String savePerson(@ModelAttribute Person2 person, Model model) {

		Person2 save = service.save(person);
		model.addAttribute("save", save);
		return "saveperson";
	}

	@PostMapping("/login")
	public String loginForm(@RequestParam Integer id,@RequestParam String password,Model model) {
		Person2 person = service.getPersonByIdAndPassword(id,password);
		model.addAttribute("person",person);
		return "welcome";
	}
	
}
