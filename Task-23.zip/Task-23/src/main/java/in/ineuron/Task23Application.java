package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.model.Person2;
import in.ineuron.service.IPersonService;

@SpringBootApplication
public class Task23Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Task23Application.class, args);
		IPersonService service = context.getBean(IPersonService.class);
		Person2 person = service.getPersonByIdAndPassword(2, "abc");
		System.out.println(person);
	}

}
