package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.PersonRepository;
import in.ineuron.model.Person2;

@Service
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private PersonRepository repo;
	
	@Override
	public Person2 save(Person2 p) {
		// TODO Auto-generated method stub
		return repo.save(p);
	}

	@Override
	public Person2 getPersonByIdAndPassword(Integer id, String password) {
		// TODO Auto-generated method stub
		Person2 person = repo.findPersonByIdAndPassword(id, password);
		return person;
	}

}
