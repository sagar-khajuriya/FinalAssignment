package in.ineuron.main;

public class Child extends Parent {

	public Child() {
		super();
		System.out.println("Child Class constructor invoked");
	}
	
}
