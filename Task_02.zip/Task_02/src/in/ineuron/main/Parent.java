package in.ineuron.main;

public class Parent {

	public Parent() {
		System.out.println("Parent Class constructor invoked");
	}
	
}
