package in.ineuron.main;

public class MainClass {

	public static void main(String[] args) {
		new Child();
	}
}
//Key Points
/*
:- It is a special member method.
:- Its task is to initialize the object.
:- It gets call automatically when the object is created.
:- Its name is same as Class Name.
:- We can overload the constructor but can not override it.
:- It does not participate in Inheritance.
:- when the child class constructor is invoked then the parent class constructor gets invoke automatically
:- Types of Constructor : No-args constructor and Parameterized constructor
:- Constructor can not be a type of static final and abstract.
:- Constructor can be public,private,protected and default.



*/