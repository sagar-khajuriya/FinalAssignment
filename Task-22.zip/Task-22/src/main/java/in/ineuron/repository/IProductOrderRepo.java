package in.ineuron.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Customer;
import in.ineuron.model.ProductOrder;

public interface IProductOrderRepo extends JpaRepository<ProductOrder, Integer> {

	List<ProductOrder> findByCustomer(Customer customer);
	
}
