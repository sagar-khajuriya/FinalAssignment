package in.ineuron;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import in.ineuron.model.Customer;
import in.ineuron.model.ProductOrder;
import in.ineuron.service.ICustomerService;
import in.ineuron.service.IProductOrderService;

@SpringBootApplication
public class Task22Application {
// Here a Customer can register
// can order any products
// can see list of Ordered products
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Task22Application.class, args);

		while (true) {
			System.out.println("***************************");
			System.out.println("Welcome to E-Commerce Web");
			System.out.println("Enter Your Choice");
			System.out.println("1. To Register");
			System.out.println("2. To Order");
			System.out.println("3. To Get Order List");
			System.out.println("4. To Exit");

			Scanner scanner = new Scanner(System.in);
			Integer choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				saveCustomer(context);
				break;

			}
			case 2: {
				placeOrder(context);
				break;
			}
			case 3: {
				orderList(context);
				break;
			}
			case 4: {
				System.exit(0);
			}
			default:
				System.out.println("Invalid Choice ");
			}

		}

	}

	private static void orderList(ApplicationContext context) {
		IProductOrderService productService = context.getBean(IProductOrderService.class);
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Id to get Order List      : ");
		Integer id = scanner.nextInt();
		List<ProductOrder> orderList = productService.getOrderListById(id);
		if (orderList != null) {
			System.out.println("Your Order List is : ");
			orderList.forEach(product -> System.out.println(product));
		} else {
			System.out.println("You Order List Is Empty ");
		}
	}

	private static void placeOrder(ApplicationContext context) {
		IProductOrderService productService = context.getBean(IProductOrderService.class);
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Product Name      : ");
		String name = scanner.next();
		System.out.print("Enter Product Price     : ");
		Float price = scanner.nextFloat();
		System.out.print("Enter Product Quantity  : ");
		Integer quantity = scanner.nextInt();
		System.out.println("Enter Customer Id     :");
		Integer id = scanner.nextInt();

		Customer customer = new Customer();
		customer.setCustomerId(id);
		ProductOrder order = new ProductOrder();
		order.setProductName(name);
		order.setProductPrice(price);
		order.setProductQuantity(quantity);
		order.setCustomer(customer);

		String orderNo = productService.placeOrder(order);
		if (orderNo.equals("customerNotFound")) {
			System.out.println("You are not Logined");
		} else {
			System.out.println("Your Order is placed successfully & order Number is : " + orderNo);
		}
	}

	private static void saveCustomer(ApplicationContext context) {
		ICustomerService customerService = context.getBean(ICustomerService.class);
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your Name : ");
		String name = scanner.next();
		System.out.print("Enter your Address : ");
		String address = scanner.next();
		System.out.print("Enter your Contact: ");
		Long contact = scanner.nextLong();
		Customer customer = new Customer();
		customer.setCustomerName(name);
		customer.setCustomerAddress(address);
		customer.setCustomercontact(contact);

		String saveCustomer = customerService.saveCustomer(customer);
		System.out.println("Your User Id is : " + saveCustomer);
	}

}
