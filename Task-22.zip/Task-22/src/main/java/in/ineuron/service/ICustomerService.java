package in.ineuron.service;

import in.ineuron.model.Customer;

public interface ICustomerService {

	public String saveCustomer(Customer customer);
	
	public Customer findCustomerById(Integer id);
	
}
