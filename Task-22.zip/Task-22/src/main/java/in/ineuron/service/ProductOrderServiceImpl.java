package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.model.Customer;
import in.ineuron.model.ProductOrder;
import in.ineuron.repository.ICustomerRepo;
import in.ineuron.repository.IProductOrderRepo;

@Service
public class ProductOrderServiceImpl implements IProductOrderService {
	@Autowired
	private IProductOrderRepo orderRepo;
	@Autowired
	private ICustomerRepo customerRepo;

	@Override
	public String placeOrder(ProductOrder order) {
		// TODO Auto-generated method stub
		String orderNo ="customerNotFound";
		Integer customerId = order.getCustomer().getCustomerId();
		Optional<Customer> customer = customerRepo.findById(customerId);
		if(customer.isPresent()) {
		orderNo = orderRepo.save(order).getOrderNo().toString();
		}
		return orderNo;
	}

	@Override
	public List<ProductOrder> getOrderListById(Integer id) {
		// TODO Auto-generated method stub
		List<ProductOrder> orderList = null;
		Optional<Customer> customer = customerRepo.findById(id);
		if (customer.isPresent()) {
			orderList = orderRepo.findByCustomer(customer.get());
		}
		return orderList;
	}

}
