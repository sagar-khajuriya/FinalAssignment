package in.ineuron.service;

import java.util.List;

import in.ineuron.model.ProductOrder;

public interface IProductOrderService {

	public String placeOrder(ProductOrder order);

	public List<ProductOrder> getOrderListById(Integer id);

}
