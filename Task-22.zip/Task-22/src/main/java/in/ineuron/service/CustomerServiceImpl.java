package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.model.Customer;
import in.ineuron.repository.ICustomerRepo;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerRepo repo;

	@Override
	public String saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer save = repo.save(customer);
		String id = save.getCustomerId().toString();
		return id;
	}

	@Override
	public Customer findCustomerById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

}
