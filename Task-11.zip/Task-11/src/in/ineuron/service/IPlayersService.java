package in.ineuron.service;

import java.util.List;

import in.ineuron.dto.Players;

public interface IPlayersService {

	public List<Players> getAllPlayers();
	
}
