package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IPlayersDao;
import in.ineuron.dao.PlayersDaoImpl;
import in.ineuron.dto.Players;

public class PlayersServiceImpl implements IPlayersService {

	IPlayersDao dao=new PlayersDaoImpl();
	
	@Override
	public List<Players> getAllPlayers() {
		List<Players> players = dao.getAllPlayers();
		return players;
	}

}
