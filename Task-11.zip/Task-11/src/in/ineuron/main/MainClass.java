package in.ineuron.main;

import java.util.List;

import in.ineuron.dto.Players;
import in.ineuron.service.IPlayersService;
import in.ineuron.service.PlayersServiceImpl;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IPlayersService service = new PlayersServiceImpl();

		List<Players> allPlayers = service.getAllPlayers();

		System.out.println("------------------------------------------------------------------------");
		System.out.println("ID \t NAME \t\t AGE \t ADDRESS \t DESIGNATION \t SALARY");
		System.out.println("------------------------------------------------------------------------");
		for (Players p : allPlayers) {
			System.out.println(p.getId() + " \t " + p.getName() + " \t " + p.getAge() + " \t " + p.getAddress() + " \t\t "
					+ p.getDesignation() + " \t " + p.getSalary());
		}
		System.out.println("------------------------------------------------------------------------");
	}

}
