package in.ineuron.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.Players;
import in.ineuron.util.JDBCUtils;

public class PlayersDaoImpl implements IPlayersDao {

	private Connection connection;
	private PreparedStatement prepareStatement;
	private ResultSet resultSet;
	private List<Players> list;

	@Override
	public List<Players> getAllPlayers() {
		connection = JDBCUtils.getConnection();
		try {

			if (connection != null) {
				prepareStatement = connection.prepareStatement("select * from players");
			}

			if (prepareStatement != null) {
				resultSet = prepareStatement.executeQuery();
			}

			if (resultSet != null) {
				list = new ArrayList<>();
				while (resultSet.next()) {
					Players players = new Players();
					players.setId(resultSet.getInt(1));
					players.setName(resultSet.getString(2));
					players.setAge(resultSet.getInt(3));
					players.setAddress(resultSet.getString(4));
					players.setDesignation(resultSet.getString(5));
					players.setSalary(resultSet.getInt(6));
					list.add(players);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
