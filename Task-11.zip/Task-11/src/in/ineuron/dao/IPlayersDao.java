package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.Players;

public interface IPlayersDao {

	public List<Players> getAllPlayers();
	
}
