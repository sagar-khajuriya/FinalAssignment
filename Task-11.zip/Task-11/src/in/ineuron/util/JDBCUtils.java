package in.ineuron.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtils {
	private static Connection connection;

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private JDBCUtils() {

	}

	public static Connection getConnection() {
		if (connection == null)
			try {
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ineuron", "root", "password");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return connection;
	}

	public static void closeConnection() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
