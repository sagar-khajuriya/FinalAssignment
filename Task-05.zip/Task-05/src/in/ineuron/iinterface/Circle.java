package in.ineuron.iinterface;

import java.util.Scanner;

public class Circle implements Shape {

	Scanner scan=new Scanner(System.in);
	@Override
	public Float area() {
		System.out.print("Enter the radius : ");
		float radius = scan.nextFloat();
		return 3.14f*radius*radius;
	}

	@Override
	public Float perimeter() {
		System.out.print("Enter the radius : ");
		float radius = scan.nextFloat();
		return 2*3.14f*radius;
	}

	public static void main(String[] args) {
		Circle circle = new Circle();
		System.out.println("Area of circle is      : "+ circle.area());
		System.out.println("Perimeter of circle is : "+circle.perimeter());
	}
	
}
/*
Key Points
:- interface is an extended form of abstract class or it is a SRS or API.
:- We can not instantiate the interface.
:- All the methods in interface is by default public and abstract.
:- All the variables in interface is by default public static and final.
:- It do not have constructors.
:- if any class implements interface then it is necessary to give the implementation
to all the methods of interface otherwise we have to declare a class as abstract.
:- By using interface we can achieve multiple inheritance in java.
*/