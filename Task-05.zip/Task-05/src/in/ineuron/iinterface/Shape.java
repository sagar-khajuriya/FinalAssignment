package in.ineuron.iinterface;

public interface Shape {

	public Float area();
	
	public Float perimeter();
	
}
