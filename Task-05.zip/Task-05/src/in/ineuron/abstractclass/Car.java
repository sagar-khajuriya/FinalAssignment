package in.ineuron.abstractclass;

public abstract class Car {

	public Car() {
		System.out.println("Abstract Car Class Constructor");
	}
	
	public abstract void model();

	public abstract int engineCC();
	
	public void carColor() {
		System.out.println("Car Basic Color : White Perl");
	}
	
	
	
}
