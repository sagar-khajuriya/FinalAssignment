package in.ineuron.abstractclass;

public class HondaCar extends Car {

	public HondaCar() {
		System.out.println("HondaCar class Constructor");
	}

	@Override
	public void model() {
		System.out.println("Car Model is  : HatchBack");
	}

	@Override
	public int engineCC() {
		return 1500;
	}

	public static void main(String[] args) {

		HondaCar hondaCar = new HondaCar();
		hondaCar.carColor();
		hondaCar.model();
		int engineCC = hondaCar.engineCC();
		System.out.println("Engine Power is : " + engineCC + "CC");
	}

}
/*
 Key Points
 :- A class declared with abstract is known as abstract class.
 :- we can not instantiate the abstract class.
 :- An abstract class can have abstract and non-abstract method.
 :- An abstract method can not have body.
 :- An abstract class can have public static and final variables.
 :- An abstract class can have constructor also.
 :- If any class extends abstract class then it is compulsory to override all the 
 abstract method of abstract class.
 */