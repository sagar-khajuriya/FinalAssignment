package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.exception.NegativeNumberException;

public class MainClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);

		System.out.print("Enter the number : ");
		int num = scan.nextInt();
		try {
			if (num < 0) {
				throw new NegativeNumberException("Entered number is negative : " + num);
			} else {
				System.out.println("Entered Number is Positive : " + num);
			}
		} catch (NegativeNumberException e) {
			System.out.println(e.getMessage() + " \nplease enter positive number");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
