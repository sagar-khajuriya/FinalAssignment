package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.exception.NegativeNumberException;

public class MainClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);

		System.out.print("Enter the number : ");
		int num = scan.nextInt();

		if (num < 0) {
			throw new NegativeNumberException("entered number is negative : " + num);
		}

	}

}
