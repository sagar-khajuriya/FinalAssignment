package in.ineuron.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MainClass {
	static {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;
		FileReader fr = null;
		BufferedReader br = null;
		try {

			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/sample", "postgres", "password");

			if (connection != null) {
				pstmt = connection.prepareStatement("insert into person (id,name,age,address) values (?,?,?,?)");
			}

			if (pstmt != null) {
				fr = new FileReader("sample3.csv");
				br = new BufferedReader(fr);
				String readLine = br.readLine();
				while (readLine != null) {
					String[] data = readLine.split(" ");
					pstmt.setInt(1, Integer.parseInt(data[0]));
					pstmt.setString(2, data[1]);
					pstmt.setString(3, data[2]);
					pstmt.setString(4, data[3]);

					pstmt.addBatch();
					readLine = br.readLine();
				}
				int[] rowAffected = pstmt.executeBatch();
				int record = rowAffected.length;
				if (record == 0) {
					System.out.println("Record not stored in DataBase");
				} else {
					System.out.println(record + " Record inserted successfully in DataBase");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				br.close();
			}
			if (fr != null) {
				fr.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (connection != null) {
				connection.close();
			}
		}

	}

}
