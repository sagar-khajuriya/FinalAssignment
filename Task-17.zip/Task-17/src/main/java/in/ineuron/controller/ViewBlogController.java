package in.ineuron.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.CreateBlogPost;
import in.ineuron.service.IBlogService;
import in.ineuron.servicefactory.BlogServiceFactory;


@WebServlet("/viewblog")
public class ViewBlogController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IBlogService service = BlogServiceFactory.getBlogService();
		List<CreateBlogPost> allBlogs = service.getAllBlogs();
		System.out.println(allBlogs);
		
		request.setAttribute("allBlogs", allBlogs);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/viewblog.jsp");
		requestDispatcher.forward(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
