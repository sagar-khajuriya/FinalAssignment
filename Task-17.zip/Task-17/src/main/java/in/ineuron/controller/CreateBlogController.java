package in.ineuron.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.CreateBlogPost;
import in.ineuron.service.IBlogService;
import in.ineuron.servicefactory.BlogServiceFactory;


@WebServlet("/createblog")
public class CreateBlogController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CreateBlogPost post = new CreateBlogPost();
		post.setTitle(request.getParameter("title"));
		post.setDescription(request.getParameter("description"));
		post.setContent(request.getParameter("content"));
		
		IBlogService service = BlogServiceFactory.getBlogService();
		String result = service.createBlog(post);
		
		request.setAttribute("result", result);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/createblog.jsp");
		requestDispatcher.forward(request, response);
	
	}

}
