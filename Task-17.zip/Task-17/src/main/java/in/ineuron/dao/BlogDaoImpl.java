package in.ineuron.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.CreateBlogPost;
import in.ineuron.util.JdbcUtil;

public class BlogDaoImpl implements IBlogDao {

	private Connection connection = null;
	private PreparedStatement pstmt = null;
	private ResultSet resultSet = null;
	private List<CreateBlogPost> list = null;

	@Override
	public List<CreateBlogPost> getAllBlogs() {
		// TODO Auto-generated method stub

		try {
			connection = JdbcUtil.getConnection();

			if (connection != null) {
				pstmt = connection.prepareStatement("select * from blog");
			}
			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}
			if (resultSet != null) {
				list=new ArrayList<>();
				while (resultSet.next()) {
					CreateBlogPost post = new CreateBlogPost();
					post.setBlogId(resultSet.getInt("bid"));
					post.setTitle(resultSet.getString("title"));
					post.setDescription(resultSet.getString("description"));
					post.setContent(resultSet.getString("content"));
					list.add(post);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public String createBlog(CreateBlogPost cbp) {
		// TODO Auto-generated method stub

		try {
			connection = JdbcUtil.getConnection();

			if (connection != null) {
				pstmt = connection.prepareStatement("Insert into blog (title,description,content) values (?,?,?)");
			}
			if (pstmt != null) {
				pstmt.setString(1, cbp.getTitle());
				pstmt.setString(2, cbp.getDescription());
				pstmt.setString(3, cbp.getContent());

				int rowAffected = pstmt.executeUpdate();

				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "fail";
	}

	@Override
	public String subscription(String mailId) {
		// TODO Auto-generated method stub
		try {
			connection = JdbcUtil.getConnection();

			if (connection != null) {
				pstmt = connection.prepareStatement("insert into subscription (email) values (?)");
			}
			if (pstmt != null) {
				pstmt.setString(1, mailId);

				int rowAffected = pstmt.executeUpdate();

				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "fail";
	}

}
