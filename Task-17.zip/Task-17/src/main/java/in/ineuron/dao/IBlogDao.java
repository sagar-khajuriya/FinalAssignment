package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.CreateBlogPost;

public interface IBlogDao {

	public List<CreateBlogPost> getAllBlogs();
	
	public String createBlog(CreateBlogPost cbp);
	
	public String subscription(String mailId);
	
}
