package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IBlogDao;
import in.ineuron.daofactory.BlogDaoFactory;
import in.ineuron.dto.CreateBlogPost;

public class BlogServiceImpl implements IBlogService {
	
	private IBlogDao dao=BlogDaoFactory.getBlogDao();

	@Override
	public List<CreateBlogPost> getAllBlogs() {
		// TODO Auto-generated method stub
		return dao.getAllBlogs();
	}

	@Override
	public String createBlog(CreateBlogPost cbp) {
		// TODO Auto-generated method stub
		return dao.createBlog(cbp);
	}

	@Override
	public String subscription(String mailId) {
		// TODO Auto-generated method stub
		return dao.subscription(mailId);
	}

}
