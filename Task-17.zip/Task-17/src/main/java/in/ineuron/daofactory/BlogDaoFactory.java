package in.ineuron.daofactory;

import in.ineuron.dao.BlogDaoImpl;
import in.ineuron.dao.IBlogDao;

public class BlogDaoFactory {

	private static IBlogDao dao = null;

	private BlogDaoFactory() {
		// TODO Auto-generated constructor stub
	}
	
	public static IBlogDao getBlogDao() {
		if(dao==null) {
			dao=new BlogDaoImpl();
		}
		return dao;
	}

}
