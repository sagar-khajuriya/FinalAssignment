package in.ineuron.service;

import in.ineuron.model.Person2;

public interface IPersonService {

	public Person2 save(Person2 p);

}
