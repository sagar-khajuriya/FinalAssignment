package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task21Application {

	public static void main(String[] args) {
		SpringApplication.run(Task21Application.class, args);
	}

}
