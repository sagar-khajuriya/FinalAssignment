package in.ineuron.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import in.ineuron.dto.Player;
import in.ineuron.service.IPlayersService;
import in.ineuron.service.PlayersServiceImpl;

public class MainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		IPlayersService service = new PlayersServiceImpl();

		Scanner sc = new Scanner(System.in);
		while (true) {

			System.out.println("1.CREATE");
			System.out.println("2.READ");
			System.out.println("3.DELETE");
			System.out.println("4.UPDATE");
			System.out.println("5.GET_ALL");
			System.out.println("6.EXIT");
			System.out.println("Enter Your Choice ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1: {
				savePlayer(service);
				break;
			}
			case 2: {
				search(service);
				break;
			}
			case 3: {
				deletePlayer(service);
				break;
			}
			case 4: {
				updatePlayer(service);
				break;
			}
			case 5: {
				getAllPlayers(service);
				break;
			}
			case 6: {
				System.out.println("Thanks For Visiting......");
				System.exit(0);
			}
			default:
				System.out.println("Invalid Choice Enter Again");
			}

		}
	}

	private static void updatePlayer(IPlayersService service) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter id : ");
		String id = br.readLine();
		Player player = service.getPlayerById(Integer.parseInt(id));
		if (player != null) {

			Player newPlayer = new Player();
			newPlayer.setId(player.getId());
			System.out.println("Player id is         : " + player.getId());

			System.out.print("Player Old Name is   : " + player.getName() + "  Enter new Name : ");
			String name = br.readLine();
			if (name == null || name.equals("")) {
				newPlayer.setName(player.getName());
			} else {
				newPlayer.setName(name);
			}

			System.out.print("Player Old Age is   : " + player.getAge() + "  Enter new Age : ");
			String age = br.readLine();
			if (age.equals("")) {
				newPlayer.setAge(player.getAge());
			} else {
				newPlayer.setAge(Integer.parseInt(age));
			}

			System.out.print("Player Old Address is   : " + player.getAddress() + "  Enter new address : ");
			String address = br.readLine();
			if (address.equals("")) {
				newPlayer.setAddress(player.getAddress());
			} else {
				newPlayer.setAddress(address);
			}

			System.out.print("Player Old Designation is   : " + player.getDesignation() + "  Enter new Designation : ");
			String design = br.readLine();
			if (design.equals("")) {
				newPlayer.setDesignation(player.getDesignation());
			} else {
				newPlayer.setDesignation(design);
			}

			System.out.print("Player Old Salary is   : " + player.getSalary() + "  Enter new Salary : ");
			String salary = br.readLine();
			if (salary.equals("")) {
				newPlayer.setSalary(player.getSalary());
			} else {
				newPlayer.setSalary(Integer.parseInt(salary));
			}

			String result = service.updatePlayer(newPlayer);
			if (result.equals("success")) {
				System.out.println("Record Updated Successfully");
			} else {
				System.out.println("Record Updation Failed");
			}

		} else {
			System.out.println("Record not available for updation of Id : " + id);
		}
	}

	private static void deletePlayer(IPlayersService service) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Id  : ");
		int id = sc.nextInt();
		Player player = service.getPlayerById(id);
		if (player != null) {
			String result = service.deletePlayerById(id);
			if (result.equals("success")) {
				System.out.println("Record Deleted Successfully");
			} else {
				System.out.println("Record Deletion Failed");
			}
		} else {
			System.out.println("Record not found for deletion of Id : " + id);
		}
	}

	private static void savePlayer(IPlayersService service) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Name        : ");
		String name = sc.next();
		System.out.print("Enter the Age         : ");
		int age = sc.nextInt();
		System.out.print("Enter the Address     : ");
		String address = sc.next();
		System.out.print("Enter the Designation : ");
		String desig = sc.next();
		System.out.print("Enter the Salary      : ");
		int salary = sc.nextInt();

		Player player = new Player();
		player.setName(name);
		player.setAge(age);
		player.setAddress(address);
		player.setDesignation(desig);
		player.setSalary(salary);

		String result = service.savePlayer(player);
		if (result.equals("success")) {
			System.out.println("Record Inserted Successfully");
		} else {
			System.out.println("Record Insertion Failed");
		}
	}

	private static void search(IPlayersService service) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id : ");
		int id = sc.nextInt();
		Player player = service.getPlayerById(id);
		if (player == null) {
			System.out.println("Record not available for Id " + id);
		} else {
			System.out.println(player);
		}
	}

	private static void getAllPlayers(IPlayersService service) {
		List<Player> allPlayers = service.getAllPlayers();

		System.out.println("------------------------------------------------------------------------");
		System.out.println("ID \t NAME \t\t AGE \t ADDRESS \t DESIGNATION \t SALARY");
		System.out.println("------------------------------------------------------------------------");
		for (Player p : allPlayers) {
			System.out.println(p.getId() + " \t " + p.getName() + " \t " + p.getAge() + " \t " + p.getAddress()
					+ " \t\t " + p.getDesignation() + " \t " + p.getSalary());
		}
		System.out.println("------------------------------------------------------------------------");
	}

}
