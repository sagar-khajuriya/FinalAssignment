package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.Player;

public interface IPlayersDao {

	public List<Player> getAllPlayers();

	public Player getPlayerById(Integer id); 

	public String savePlayer(Player p);
	
	public String deletePlayerById(Integer id);
	
	public String updatePlayer(Player p);
}
