package in.ineuron.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.Player;
import in.ineuron.util.JDBCUtils;

public class PlayersDaoImpl implements IPlayersDao {

	private Connection connection;
	private PreparedStatement prepareStatement;
	private ResultSet resultSet;
	private List<Player> list;

	@Override
	public List<Player> getAllPlayers() {
		connection = JDBCUtils.getConnection();
		try {

			if (connection != null) {
				prepareStatement = connection.prepareStatement("select * from players");
			}

			if (prepareStatement != null) {
				resultSet = prepareStatement.executeQuery();
			}

			if (resultSet != null) {
				list = new ArrayList<>();
				while (resultSet.next()) {
					Player players = new Player();
					players.setId(resultSet.getInt(1));
					players.setName(resultSet.getString(2));
					players.setAge(resultSet.getInt(3));
					players.setAddress(resultSet.getString(4));
					players.setDesignation(resultSet.getString(5));
					players.setSalary(resultSet.getInt(6));
					list.add(players);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Player getPlayerById(Integer id) {
		connection = JDBCUtils.getConnection();
		Player p = null;
		try {
			if (connection != null) {
				prepareStatement = connection.prepareStatement("select * from players where id=?");
			}
			if (prepareStatement != null) {
				prepareStatement.setInt(1, id);
				resultSet = prepareStatement.executeQuery();
			}
			if (resultSet != null) {
				if (resultSet.next()) {
					p = new Player();
					p.setId(resultSet.getInt(1));
					p.setName(resultSet.getString(2));
					p.setAge(resultSet.getInt(3));
					p.setAddress(resultSet.getString(4));
					p.setDesignation(resultSet.getString(5));
					p.setSalary(resultSet.getInt(6));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public String savePlayer(Player p) {
		// TODO Auto-generated method stub
		connection = JDBCUtils.getConnection();
		String sqlInsertQuery = "insert into players (name,age,address,designation,salary) values(?,?,?,?,?)";
		try {
			if (connection != null) {
				prepareStatement = connection.prepareStatement(sqlInsertQuery);
			}
			if (prepareStatement != null) {
				prepareStatement.setString(1, p.getName());
				prepareStatement.setInt(2, p.getAge());
				prepareStatement.setString(3, p.getAddress());
				prepareStatement.setString(4, p.getDesignation());
				prepareStatement.setInt(5, p.getSalary());

				int rowAffected = prepareStatement.executeUpdate();

				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "fail";
	}

	@Override
	public String deletePlayerById(Integer id) {
		connection = JDBCUtils.getConnection();
		String sqlDeleteQuery = "delete from players where id=?";
		try {
			if (connection != null) {
				prepareStatement = connection.prepareStatement(sqlDeleteQuery);
			}
			if (prepareStatement != null) {
				prepareStatement.setInt(1, id);
				int rowAffected = prepareStatement.executeUpdate();

				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "fail";
	}

	@Override
	public String updatePlayer(Player p) {
		connection = JDBCUtils.getConnection();
		String sqlUpdateQuery = "update players set name=?, age=?,address=?,designation=?,salary=? where id=?";
		try {
			if (connection != null) {
				prepareStatement = connection.prepareStatement(sqlUpdateQuery);
			}
			if (prepareStatement != null) {
				prepareStatement.setString(1, p.getName());
				prepareStatement.setInt(2, p.getAge());
				prepareStatement.setString(3, p.getAddress());
				prepareStatement.setString(4, p.getDesignation());
				prepareStatement.setInt(5, p.getSalary());
				prepareStatement.setInt(6, p.getId());

				int rowAffected = prepareStatement.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "fail";
	}

}
