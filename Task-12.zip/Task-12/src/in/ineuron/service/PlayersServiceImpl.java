package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IPlayersDao;
import in.ineuron.dao.PlayersDaoImpl;
import in.ineuron.dto.Player;

public class PlayersServiceImpl implements IPlayersService {

	IPlayersDao dao=new PlayersDaoImpl();
	
	@Override
	public List<Player> getAllPlayers() {
		List<Player> players = dao.getAllPlayers();
		return players;
	}

	@Override
	public Player getPlayerById(Integer id) {
		// TODO Auto-generated method stub
		return dao.getPlayerById(id);
	}

	@Override
	public String savePlayer(Player p) {
		// TODO Auto-generated method stub
		return dao.savePlayer(p);
	}

	@Override
	public String deletePlayerById(Integer id) {
		// TODO Auto-generated method stub
		return dao.deletePlayerById(id);
	}

	@Override
	public String updatePlayer(Player p) {
		// TODO Auto-generated method stub
		return dao.updatePlayer(p);
	}

}
