package in.ineuron.service;

import java.util.List;

import in.ineuron.dto.Player;

public interface IPlayersService {

	public List<Player> getAllPlayers();
	
	public Player getPlayerById(Integer id); 

	public String savePlayer(Player p);
	
	public String deletePlayerById(Integer id);
	
	public String updatePlayer(Player p);
}
