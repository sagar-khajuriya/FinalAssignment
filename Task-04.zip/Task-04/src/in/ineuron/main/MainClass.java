package in.ineuron.main;

import java.util.Scanner;

public class MainClass {
	private static Float balance = 10000.0f;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("**********Welcome To Customer's Bank************");

		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.println("Enter your choice 1.Balance 2.Deposit 3.Withdraw 4.Exit");
			int choice = scan.nextInt();
			switch (choice) {
			case 1: {
				balanceCheck();
				break;
			}
			case 2: {
				DepositMoney();
				break;

			}
			case 3: {
				withdrawMoney();
				break;

			}
			case 4: {
				System.exit(0);
			}
			default:
				System.out.println("Invalid choice please choose again");

			}

		}
	}

	private static void withdrawMoney() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the amount to withdraw the money : ");
		int amount = scan.nextInt();
		balance = balance - amount;
		System.out.println("*************************************");
	}

	private static void balanceCheck() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Your balance is : " + balance);
		System.out.println("*************************************");
	}

	private static void DepositMoney() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the amount to deposit the money : ");
		float amount = scan.nextFloat();
		balance = balance + amount;
		System.out.println("Money is credited to your account successfully");
		System.out.println("*************************************");
	}

}
