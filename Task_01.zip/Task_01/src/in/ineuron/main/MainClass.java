package in.ineuron.main;

import in.ineuron.service.Circle;
import in.ineuron.service.Triangle;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circle circle = new Circle();
		System.out.println("********Area of Circle***********");
		System.out.println("Area of circle is : "+circle.area());
		System.out.println("*********************************");

		System.out.println("********Perimeter of Circle******");
		System.out.println("Perimeter of circle is : "+circle.perimeter());
		System.out.println("*********************************");
		Triangle triangle = new Triangle();
		System.out.println("********Area of Triangle**********");
		System.out.println("Area of triangle is : "+triangle.area());
		System.out.println("**********************************");
		
		System.out.println("********Perimeter of Triangle*****");
		System.out.println("Perimeter of circle is : "+triangle.perimeter());
		System.out.println("**********************************");
	}

}
