package in.ineuron.service;

import java.util.Scanner;

public class Triangle implements Shape {
	Scanner scan=new Scanner(System.in);
	@Override
	public Float area() {
		System.out.print("Enter the height of triangle : ");
		Float height = scan.nextFloat();
		System.out.print("Enter the base of triangle : ");
		Float base = scan.nextFloat();
		Float area=(height*base)/2;
		
		return area;
	}

	@Override
	public Float perimeter() {
		System.out.print("Enter the base of triangle : ");
		Float base = scan.nextFloat();
		System.out.print("Enter the side one of triangle : ");
		Float side1 = scan.nextFloat();
		System.out.print("Enter the side two of triangle : ");
		Float side2 = scan.nextFloat();
		return base+side1+side2;
	}

}
