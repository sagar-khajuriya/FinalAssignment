package in.ineuron.service;

public interface Shape {

	public Float area();
	
	public Float perimeter();
	
}
