package in.ineuron.service;

import java.util.Scanner;

public class Circle implements Shape {

	Scanner scan = new Scanner(System.in);

	@Override
	public Float area() {
		System.out.print("Enter the radius of Circle : ");
		Float radius = scan.nextFloat();
		Float area = 3.14f * radius * radius;
		
		return area;
	}

	@Override
	public Float perimeter() {
		System.out.print("Enter the radius of Circle : ");
		Float radius = scan.nextFloat();
		Float perimeter = 2*3.14f * radius;
		
		return perimeter;
	}

}
